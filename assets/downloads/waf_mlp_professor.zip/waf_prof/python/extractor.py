import time
import urllib.parse

request_history = {}

def extract_features(headers, uri, method, body, client_ip):
    path, _, query = uri.partition('?')
    query = urllib.parse.unquote(query)
    body = urllib.parse.unquote(body)
    
    is_post_put = 1 if method in ['POST', 'PUT'] else 0
    query_length = len(query)
    body_length = len(body)
    
    special_chars = "'\"<>%;()[]"
    special_chars_query = sum(1 for c in query if c in special_chars)
    special_chars_body = sum(1 for c in body if c in special_chars)
    
    q_up = query.upper()
    b_up = body.upper()
    sql_words = ["UNION", "SELECT", "OR 1=1", "DROP"]
    has_sql = 1 if any(w in q_up or w in b_up for w in sql_words) else 0
    
    xss_words = ["<SCRIPT", "JAVASCRIPT:", "ONERROR"]
    has_xss = 1 if any(w in q_up or w in b_up for w in xss_words) else 0
    
    ua = headers.get("User-Agent", "").lower()
    is_standard = 1 if any(b in ua for b in ["mozilla", "chrome", "safari"]) else 0
    
    now = time.time()
    if client_ip not in request_history:
        request_history[client_ip] = []
    request_history[client_ip] = [t for t in request_history[client_ip] if now - t < 60]
    request_history[client_ip].append(now)
    req_rate = len(request_history[client_ip])
    
    return [
        is_post_put, min(1.0, query_length / 200.0), min(1.0, body_length / 1000.0),
        min(1.0, special_chars_query / 30.0), min(1.0, special_chars_body / 50.0),
        has_sql, has_xss, is_standard, min(1.0, req_rate / 200.0)
    ]

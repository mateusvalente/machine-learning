import math
import random
import json

def sigmoid(x):
    x = max(-709, min(709, x))
    return 1 / (1 + math.exp(-x))

class MLP:
    def __init__(self, input_size, hidden_size, output_size):
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.W1 = [[random.uniform(-1, 1) for _ in range(hidden_size)] for _ in range(input_size)]
        self.b1 = [random.uniform(-1, 1) for _ in range(hidden_size)]
        self.W2 = [[random.uniform(-1, 1) for _ in range(output_size)] for _ in range(hidden_size)]
        self.b2 = [random.uniform(-1, 1) for _ in range(output_size)]

    def forward(self, X):
        self.hidden = []
        for j in range(self.hidden_size):
            act = self.b1[j]
            for i in range(self.input_size): act += X[i] * self.W1[i][j]
            self.hidden.append(sigmoid(act))
        self.output = []
        for k in range(self.output_size):
            act = self.b2[k]
            for j in range(self.hidden_size): act += self.hidden[j] * self.W2[j][k]
            self.output.append(sigmoid(act))
        return self.output

    def backward(self, X, y, lr=0.01):
        out_delta = [(y[k] - self.output[k]) * (self.output[k] * (1 - self.output[k])) for k in range(self.output_size)]
        hid_err = [sum(out_delta[k] * self.W2[j][k] for k in range(self.output_size)) for j in range(self.hidden_size)]
        hid_delta = [hid_err[j] * (self.hidden[j] * (1 - self.hidden[j])) for j in range(self.hidden_size)]
        for j in range(self.hidden_size):
            for k in range(self.output_size): self.W2[j][k] += lr * out_delta[k] * self.hidden[j]
        for k in range(self.output_size): self.b2[k] += lr * out_delta[k]
        for i in range(self.input_size):
            for j in range(self.hidden_size): self.W1[i][j] += lr * hid_delta[j] * X[i]
        for j in range(self.hidden_size): self.b1[j] += lr * hid_delta[j]

    def save(self, filename):
        with open(filename, 'w') as f:
            json.dump({'W1': self.W1, 'b1': self.b1, 'W2': self.W2, 'b2': self.b2}, f)

    def load(self, filename):
        with open(filename, 'r') as f:
            data = json.load(f)
            self.W1 = data['W1']
            self.b1 = data['b1']
            self.W2 = data['W2']
            self.b2 = data['b2']

import csv
from mlp import MLP

X = []
y = []
with open('requisicoes.csv', 'r') as f:
    reader = csv.reader(f)
    for row in reader:
        inputs = [float(v) for v in row[:9]]
        inputs[1] = min(1.0, inputs[1]/200.0) 
        inputs[2] = min(1.0, inputs[2]/1000.0)
        inputs[3] = min(1.0, inputs[3]/30.0)  
        inputs[4] = min(1.0, inputs[4]/50.0)  
        inputs[8] = min(1.0, inputs[8]/200.0) 
        label = [float(row[9])]
        X.append(inputs)
        y.append(label)

mlp = MLP(input_size=9, hidden_size=10, output_size=1)
for epoch in range(100):
    for i in range(len(X)):
        mlp.forward(X[i])
        mlp.backward(X[i], y[i], lr=0.1)
mlp.save("pesos.json")

# Ambiente WAF com Inteligência Artificial

Este ambiente contém a simulação de uma aplicação protegida por um modelo de Machine Learning (Perceptron Multicamadas).

## Arquitetura
- **Nginx**: Proxy reverso que intercepta o tráfego HTTP.
- **Python**: Serviço de inteligência artificial que avalia requisições. Se seguro, usa `X-Accel-Redirect`.
- **PHP-FPM**: Simula a aplicação backend vulnerável.

## Como subir e testar
No terminal, execute:
```bash
docker compose up -d --build
```
Ao rodar este comando, o Docker **automaticamente executará o treinamento (`train.py`)** antes de subir o servidor web Python (`server.py`). O WAF já subirá pronto para funcionar! Acesse `http://localhost:8080`.

## Como ver o que a IA está analisando em tempo real
Deixe este comando rodando em uma janela do terminal para ver o treinamento e os logs de predição:
```bash
docker compose logs -f python_waf
```

## Como treinar manualmente (Opcional)
Se você fizer modificações no código da rede e quiser forçar um re-treinamento sem reiniciar tudo, rode:
```bash
docker compose exec python_waf python train.py
```
O Python lerá o `requisicoes.csv` e salvará a inteligência em `pesos.json`. Após treinar, você já pode testar no navegador ou Postman! (Lembre-se de dar restart no container se quiser recarregar os novos pesos no server).

"""
================================================================================
EXERC?CIO PR?TICO ? BALANCEADOR DE CARGA AUT?NOMO (KIT DO ALUNO)
================================================================================
Objetivo: Aplicar a mesma l?gica de Q-Learning do Agente Tamagotchi para ensinar
o balanceador a escolher o melhor servidor Docker (`node1`, `node2` ou `node3`).

Complete os 3 blocos marcados com TODO:
  1. `select_action`: Decis?o ?-greedy (30% de chance aleat?ria inicial que vai
     caindo; caso contr?rio, escolhe o servidor com a maior nota no estado atual).
  2. `calculate_reward`: Pontua??o baseada na lat?ncia HTTP (< 100ms ganha +20,
     entre 100ms e 250ms ganha +2, >= 250ms perde -15, e Timeout perde -100).
  3. `update_q_table`: Atualiza??o da nota apenas da a??o executada no estado
     de onde saiu, usando a Equa??o de Bellman.
================================================================================
"""

import json
import random
import time
import requests

NGINX_BASE_URL = "http://localhost:8080"
REQUEST_TIMEOUT_SEC = 0.50  # 500ms

# Matriz 3x3: 3 Estados de Carga x 3 A??es (Servidores)
STATES = ["carga_baixa", "carga_media", "carga_alta"]
ACTIONS = ["node1", "node2", "node3"]

ALPHA = 0.25          # Taxa de aprendizado (?)
GAMMA = 0.85          # Fator de desconto (?)
EPSILON_START = 0.30  # Come?a com 30% de explora??o aleat?ria (igual ao Tamagotchi!)
EPSILON_MIN = 0.02    # Cai gradualmente at? 2%
EPSILON_DECAY = 0.995 # Fator de resfriamento por epis?dio
EPISODES = 500

# Cada estado guarda 3 notas (uma para cada servidor), todas come?ando em 0.0
Q_TABLE = {
    state: {action: 0.0 for action in ACTIONS}
    for state in STATES
}


def get_network_state(episode: int) -> str:
    return STATES[episode % len(STATES)]


def select_action(state: str, epsilon: float) -> tuple[str, str]:
    """
    TODO 1 ? TOMADA DE DECIS?O (ANTES DE AGIR):
    - Com probabilidade `epsilon` (come?a em 30% e vai caindo), sorteie uma a??o
      aleat?ria em `ACTIONS` e retorne `(acao_sorteada, "EXPLORACAO")`.
    - Caso contr?rio (Greedy), olhe APENAS as 3 notas do estado atual `Q_TABLE[state]`
      e retorne o servidor que tiver a maior nota `(melhor_acao, "EXPLOTACAO")`.
    """
    # --- IMPLEMENTE AQUI O TODO 1 ---
    if random.random() < epsilon:
        return random.choice(ACTIONS), "EXPLORACAO"

    notas_do_estado = Q_TABLE[state]
    maior_nota = max(notas_do_estado.values())
    melhores = [acao for acao, nota in notas_do_estado.items() if nota == maior_nota]
    return random.choice(melhores), "EXPLOTACAO"


def calculate_reward(latency_ms: float, timed_out: bool) -> float:
    """
    TODO 2 ? FUN??O DE RECOMPENSA (PONTUA??O DA A??O):
    - Se `timed_out` for True: retorne -100.0
    - Se `latency_ms < 100.0`: retorne +20.0
    - Se `latency_ms < 250.0`: retorne +2.0
    - Caso contr?rio: retorne -15.0
    """
    # --- IMPLEMENTE AQUI O TODO 2 ---
    if timed_out:
        return -100.0
    if latency_ms < 100.0:
        return +20.0
    if latency_ms < 250.0:
        return +2.0
    return -15.0


def update_q_table(state: str, action: str, reward: float, next_state: str) -> float:
    """
    TODO 3 ? EQUA??O DE BELLMAN (DEPOIS DE AGIR):
    Atualize APENAS a nota do servidor `action` no estado `state` de onde saiu:
    Q(s, a) <- Q(s, a) + ALPHA * [ reward + GAMMA * max(Q(s')) - Q(s, a) ]
    """
    # --- IMPLEMENTE AQUI O TODO 3 ---
    nota_atual = Q_TABLE[state][action]
    melhor_nota_futura = max(Q_TABLE[next_state].values())

    alvo_bellman = reward + (GAMMA * melhor_nota_futura)
    erro_td = alvo_bellman - nota_atual
    nova_nota = nota_atual + (ALPHA * erro_td)

    Q_TABLE[state][action] = nova_nota
    return nova_nota


def dispatch_request(action_node: str, current_state: str) -> tuple[float, bool]:
    extra_load_ms = {"carga_baixa": 0, "carga_media": 20, "carga_alta": 45}[current_state]
    url = f"{NGINX_BASE_URL}/{action_node}"
    start_time = time.perf_counter()
    try:
        response = requests.get(
            url,
            headers={"X-Network-State": current_state},
            params={"load": f"{extra_load_ms}ms"},
            timeout=REQUEST_TIMEOUT_SEC,
        )
        response.raise_for_status()
        return (time.perf_counter() - start_time) * 1000.0, False
    except requests.exceptions.Timeout:
        return (time.perf_counter() - start_time) * 1000.0, True
    except requests.exceptions.RequestException:
        base = {"node1": 24.0, "node2": 155.0, "node3": 640.0}[action_node]
        lat = max(4.0, base + extra_load_ms + random.uniform(-8.0, 18.0))
        return lat, (lat > REQUEST_TIMEOUT_SEC * 1000.0)


def main() -> None:
    epsilon = EPSILON_START
    counts = {node: 0 for node in ACTIONS}

    for episode in range(1, EPISODES + 1):
        state = get_network_state(episode)
        action, mode = select_action(state, epsilon)
        counts[action] += 1

        latency_ms, timed_out = dispatch_request(action, state)
        reward = calculate_reward(latency_ms, timed_out)
        next_state = get_network_state(episode + 1)

        new_q = update_q_table(state, action, reward, next_state)
        epsilon = max(EPSILON_MIN, epsilon * EPSILON_DECAY)

        if episode <= 5 or episode % 25 == 0 or episode == EPISODES:
            status = "TIMEOUT!" if timed_out else f"{latency_ms:6.1f}ms"
            print(f"[Ep {episode:03d}] S:{state:<11} | {action} ({mode:<10}) | {status} | R:{reward:+6.1f} | Q:{new_q:7.2f} | ?:{epsilon:.3f}")

    with open("q_table_treinada.json", "w", encoding="utf-8") as f:
        json.dump(Q_TABLE, f, indent=2, ensure_ascii=False)
    print("\nQ-Table final:", json.dumps(Q_TABLE, indent=2))


if __name__ == "__main__":
    main()
